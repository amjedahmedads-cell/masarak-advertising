(() => {
  const scriptUrl = new URL(document.currentScript.src);
  const basePath = scriptUrl.pathname.replace(/\/assets\/site\.js$/, "").replace(/\/$/, "");
  const path = location.pathname.slice(basePath.length).replace(/\/index\.html$/, "").replace(/\/+$/, "");
  const parts = path.split("/").filter(Boolean);
  const isEnglish = parts[0] === "en";
  const page = (isEnglish ? parts[1] : parts[0]) || "home";
  const pathFor = (slug, english = isEnglish) => {
    const segments = [];
    if (english) segments.push("en");
    if (slug && slug !== "home") segments.push(slug);
    return `${basePath}/${segments.join("/")}${segments.length ? "/" : ""}` || "/";
  };
  const whatsappText = isEnglish
    ? "Hello, I would like to discuss Masarak Advertising services for my business."
    : "مرحبًا، أود مناقشة خدمات مسارك الإعلاني لنشاطي.";
  const whatsappUrl = number =>
    `https://wa.me/${number}?text=${encodeURIComponent(whatsappText)}`;
  const t = isEnglish
    ? {
        brand: "Masarak Advertising",
        tagline: "Marketing that connects strategy, content, campaigns, and reporting.",
        nav: [["Home", "home"], ["Services", "services"], ["Our approach", "about"], ["Our work", "portfolio"], ["Contact", "contact"]],
        language: "العربية",
        home: {
          eyebrow: "Masarak Advertising · Remote marketing and advertising",
          title: "Strategy, content, and campaigns — on a clearer path.",
          intro: "When advertising and content are handled in separate efforts, it is hard to see the full picture. We bring planning, content, account management, campaigns, and reporting into one coordinated workflow.",
          primary: "Start a WhatsApp conversation",
          secondary: "Explore services",
          region: "Yemen first, then the Gulf",
          process: "A connected marketing path",
          processNote: "From planning to reviewing what was delivered",
          sectorsLabel: "Who we work with",
          sectorsTitle: "Services shaped around your business and audience",
          sectorsIntro: "Different businesses need different messages and channels. We tailor the conversation to your field.",
          sectors: [
            ["Online stores", "Content and campaigns that help present products and reach customers."],
            ["Clinics and health centers", "Clear advertising communication suited to healthcare services."],
            ["Restaurants and cafes", "Visual content and messages for food and hospitality offers."],
            ["Service companies", "For engineering offices, consultants, training, and technology businesses."]
          ],
          challengeLabel: "Does this sound familiar?",
          challengeTitle: "Unclear ad spend? Scattered content?",
          challengeText: "If you have run ads without understanding where the budget went, lack a strong in-house marketing team, or have disorganized accounts and content, start by identifying what your business actually needs.",
          challengeItems: ["Hard to understand where advertising spend goes", "No strong in-house marketing team", "Unplanned content and disorganized accounts"],
          asideTitle: "One partner to coordinate the moving parts.",
          asideText: "Tell us your goals and we will discuss the services that fit — from planning and content to account management, campaigns, and reporting.",
          stepsLabel: "How the work flows",
          stepsTitle: "From plan to report",
          stepsIntro: "Connected services that reduce marketing fragmentation.",
          steps: [["01", "Plan"], ["02", "Content"], ["03", "Campaign"], ["04", "Report"]],
          ctaTitle: "Ready to bring your marketing efforts into focus?",
          ctaText: "Tell us about your business and what you want to improve."
        },
        services: {
          eyebrow: "Our services",
          title: "Everything your marketing path needs, in one place.",
          intro: "Choose the service your business needs, or let us coordinate planning, content, campaigns, and reporting together.",
          items: [
            ["Marketing plan", "Organize the goals, messages, and channels your business will work with."],
            ["Photo and video production", "Create visual materials for presenting your services and products in content and campaigns."],
            ["Advertising copywriting", "Clear messages tailored to your audience, platform, and campaign goal."],
            ["Account management", "Coordinate accounts, content, and publishing for a more consistent presence."],
            ["Print advertising", "Prepare print materials your business needs to introduce its services and offers."],
            ["Advertising design", "Design materials that fit your brand, message, and channels."],
            ["Campaign management", "Set up and manage campaigns with clear communication and reporting."]
          ],
          ctaTitle: "Not sure where to start?",
          ctaText: "Tell us about your business and what you have tried so far. We will discuss an appropriate path without assumptions.",
          ctaButton: "Contact us"
        },
        about: {
          eyebrow: "About us · How we work",
          title: "When strategy, content, and campaigns come together, the picture gets clearer.",
          intro: "Masarak Advertising is a remote marketing and advertising partner. We coordinate planning, production, copywriting, account management, design, print, campaigns, and clear reporting.",
          stepsLabel: "The workflow",
          stepsTitle: "Four pillars, one connected path",
          stepsIntro: "We do not assume every business needs the same service. We start with your needs, then define what fits.",
          steps: [
            ["01", "Planning", "Set a marketing direction and services suited to what you want to achieve."],
            ["02", "Content", "Coordinate writing, photography, and design for your business and channels."],
            ["03", "Campaigns", "Manage advertising campaigns along the agreed path."],
            ["04", "Reporting", "Clearly show what was done and what needs follow-up."]
          ],
          regionTitle: "Remote work across the region",
          regionText: "Yemen is our first priority, with remote services in Saudi Arabia, the UAE, Kuwait, Qatar, Bahrain, and Oman.",
          ctaTitle: "Want to organize your marketing efforts?",
          ctaText: "Start a conversation and tell us about your business and what you want to make clearer."
        },
        portfolio: {
          eyebrow: "Our work",
          title: "Selected work, shared when it is ready.",
          intro: "We only publish work that can be shared clearly and has been approved for publication.",
          emptyTitle: "No projects published yet",
          emptyText: "There are no approved examples to show at this time. Contact us to discuss your business needs and suitable services."
        },
        contact: {
          eyebrow: "Contact us",
          title: "Let’s start with the challenge you want to solve.",
          intro: "Choose the WhatsApp number that works for you and start a direct conversation. We serve clients remotely in Yemen and the Gulf.",
          channels: "Choose a contact channel",
          channelsTitle: "Reach out in the way that works for you.",
          channelsText: "You can also call the same numbers or message us through our social accounts.",
          numberOne: "WhatsApp · Number one",
          numberTwo: "WhatsApp · Number two",
          whatsapp: "Message on WhatsApp",
          phone: "Call",
          social: "Social media",
          socialTitle: "Follow or message our official accounts:",
          remote: "We work remotely and do not list a local office address."
        },
        footerLinks: "Site links",
        footerSocial: "Contact channels",
        footerRemote: "Remote service in Yemen, Saudi Arabia, UAE, Kuwait, Qatar, Bahrain, and Oman.",
        ctaButton: "Start a WhatsApp conversation",
        countriesTitle: "Yemen first, then the Gulf",
        countries: ["Yemen", "Saudi Arabia", "UAE", "Kuwait", "Qatar", "Bahrain", "Oman"]
      }
    : {
        brand: "مسارك الإعلاني",
        tagline: "تسويق وإعلان يربط الخطة بالمحتوى والحملات والتقارير.",
        nav: [["الرئيسية", "home"], ["خدماتنا", "services"], ["منهجيتنا", "about"], ["من أعمالنا", "portfolio"], ["تواصل معنا", "contact"]],
        language: "EN",
        home: {
          eyebrow: "مسارك الإعلاني · تسويق وإعلان عن بُعد",
          title: "خطة ومحتوى وحملات… في مسار واضح.",
          intro: "حين تتوزع الإعلانات والمحتوى بين جهود متفرقة، يصعب تكوين صورة واضحة. ننسّق لك الخطة والمحتوى وإدارة الحسابات والحملات والتقارير ضمن مسار عمل واحد.",
          primary: "ابدأ محادثة عبر واتساب",
          secondary: "استكشف الخدمات",
          region: "اليمن أولًا، ثم أسواق الخليج",
          process: "مسار تسويقي مترابط",
          processNote: "من التخطيط إلى متابعة ما نُفّذ",
          sectorsLabel: "لمن نعمل",
          sectorsTitle: "خدمات تناسب طبيعة نشاطك وجمهورك",
          sectorsIntro: "نخدم أنشطة تختلف رسائلها وقنواتها، مع تخصيص التواصل بحسب المجال.",
          sectors: [
            ["المتاجر الإلكترونية", "محتوى وحملات تدعم عرض المنتجات والوصول إلى العملاء."],
            ["العيادات والمراكز الصحية", "تواصل إعلاني واضح يناسب خدمات الرعاية الصحية."],
            ["المطاعم والكافيهات", "محتوى بصري ورسائل ملائمة لعروض الطعام والضيافة."],
            ["شركات الخدمات", "للمكاتب الهندسية والاستشارات والتدريب والشركات التقنية."]
          ],
          challengeLabel: "هل يبدو هذا مألوفًا؟",
          challengeTitle: "إنفاق إعلاني بلا وضوح؟ محتوى متفرق؟",
          challengeText: "إذا جرّبت الإعلانات ولم تعرف أين ذهب الإنفاق، أو لم يتوفر لديك فريق تسويق داخلي قوي، أو أصبحت الحسابات والمحتوى غير منظمة، فابدأ بتحديد ما يحتاجه نشاطك فعلًا.",
          challengeItems: ["صعوبة فهم أين يذهب الإنفاق الإعلاني", "غياب فريق تسويق داخلي قوي", "محتوى عشوائي وحسابات غير منظمة"],
          asideTitle: "جهة واحدة تنسّق أجزاء المسار.",
          asideText: "تواصل معنا لمناقشة هدفك واختيار ما يلائم نشاطك من الخطة والمحتوى وإدارة الحسابات والحملات والتقارير.",
          stepsLabel: "تسلسل العمل",
          stepsTitle: "من الخطة إلى التقرير",
          stepsIntro: "خدمات مترابطة لتقليل تشتت العمل التسويقي.",
          steps: [["01", "خطة"], ["02", "محتوى"], ["03", "حملة"], ["04", "تقرير"]],
          ctaTitle: "هل تريد وضوحًا أكبر في جهودك التسويقية؟",
          ctaText: "شاركنا نشاطك وما تريد تحسينه."
        },
        services: {
          eyebrow: "خدماتنا",
          title: "كل ما يحتاجه المسار التسويقي، في مكان واحد.",
          intro: "اختر الخدمة التي يحتاجها نشاطك، أو ناقشنا تنسيق الخطة والمحتوى والحملات والتقارير معًا.",
          items: [
            ["إعداد خطة تسويقية", "خطة تساعد على تنظيم الأهداف والرسائل والقنوات التي سيعمل عليها النشاط."],
            ["التصوير والإنتاج المرئي", "إنتاج مواد مرئية مناسبة لعرض الخدمات والمنتجات واستخدامها في المحتوى والحملات."],
            ["كتابة المحتوى الإعلاني", "صياغة رسائل واضحة تراعي طبيعة الجمهور والمنصة والهدف من الإعلان."],
            ["إدارة الحسابات", "تنظيم الحسابات والمحتوى والنشر بما يساعد على حضور أكثر اتساقًا."],
            ["المطبوعات الإعلانية", "إعداد المواد المطبوعة التي يحتاجها النشاط للتعريف بخدماته وعروضه."],
            ["التصميم الإعلاني", "تصميم مواد إعلانية تلائم الهوية والرسالة والقنوات المستخدمة."],
            ["إدارة الحملات الإعلانية", "إعداد وإدارة الحملات ومتابعة تفاصيلها ضمن تواصل وتقارير واضحة."]
          ],
          ctaTitle: "لست متأكدًا من الخدمة التي تبدأ بها؟",
          ctaText: "اشرح لنا نشاطك وما جرّبته حتى الآن، وسنناقش معك المسار المناسب دون افتراضات مسبقة.",
          ctaButton: "تواصل معنا"
        },
        about: {
          eyebrow: "من نحن · كيف نعمل",
          title: "عندما تلتقي الخطة والمحتوى والحملات، تصبح الصورة أوضح.",
          intro: "مسارك الإعلاني جهة تسويق وإعلان تعمل عن بُعد. ننسّق خدمات إعداد الخطة والتصوير والإنتاج وكتابة المحتوى وإدارة الحسابات والتصميم والمطبوعات والحملات، مع تقارير واضحة عن العمل.",
          stepsLabel: "تسلسل العمل",
          stepsTitle: "أربع ركائز لمسار واحد",
          stepsIntro: "لا نفترض أن كل نشاط يحتاج الخدمة نفسها؛ يبدأ الحديث من احتياجك، ثم تتحدد الخدمات التي تناسبه.",
          steps: [
            ["01", "الخطة", "تحديد اتجاه تسويقي وخدمات ملائمة لما تريد مناقشته."],
            ["02", "المحتوى", "تنسيق الكتابة والتصوير والتصميم بحسب النشاط والقنوات."],
            ["03", "الحملات", "إدارة الحملات الإعلانية ضمن المسار المتفق عليه."],
            ["04", "التقارير", "عرض واضح لما تم ومتابعة ما يحتاج إلى نقاش."]
          ],
          regionTitle: "عمل عن بُعد لأسواق المنطقة",
          regionText: "اليمن هو الأولوية، وتشمل الخدمة عن بُعد السعودية والإمارات والكويت وقطر والبحرين وعُمان.",
          ctaTitle: "هل تريد ترتيب جهودك التسويقية؟",
          ctaText: "ابدأ محادثة وشاركنا نشاطك وما تريد تحسين وضوحه."
        },
        portfolio: {
          eyebrow: "من أعمالنا",
          title: "نماذج مختارة عندما تصبح جاهزة للنشر.",
          intro: "لن نعرض هنا إلا أعمالًا يمكن مشاركتها بوضوح وبعد اعتمادها للنشر.",
          emptyTitle: "لا توجد مشاريع منشورة الآن",
          emptyText: "لا تتوفر حاليًا نماذج معتمدة للنشر. تواصل معنا لمناقشة احتياج نشاطك والخدمات الملائمة له."
        },
        contact: {
          eyebrow: "تواصل معنا",
          title: "لنبدأ من التحدي الذي تريد حله.",
          intro: "اختر رقم واتساب المناسب وابدأ رسالة مباشرة. خدماتنا تُقدّم عن بُعد في اليمن وأسواق الخليج.",
          channels: "اختر قناة التواصل المناسبة",
          channelsTitle: "تواصل بالطريقة التي تناسبك.",
          channelsText: "يمكنك أيضًا الاتصال على الرقم نفسه أو مراسلتنا عبر الحسابات الاجتماعية.",
          numberOne: "واتساب · الرقم الأول",
          numberTwo: "واتساب · الرقم الثاني",
          whatsapp: "تواصل عبر واتساب",
          phone: "اتصال هاتفي",
          social: "حسابات التواصل الاجتماعي",
          socialTitle: "تابع أو راسل الحسابات الرسمية بالمعرّف:",
          remote: "نعمل عن بُعد ولا نعرض عنوان مكتب محلي."
        },
        footerLinks: "روابط الموقع",
        footerSocial: "قنوات التواصل",
        footerRemote: "خدمات عن بُعد في اليمن والسعودية والإمارات والكويت وقطر والبحرين وعُمان.",
        ctaButton: "ابدأ محادثة واتساب",
        countriesTitle: "اليمن أولًا، ثم أسواق الخليج",
        countries: ["اليمن", "السعودية", "الإمارات", "الكويت", "قطر", "البحرين", "عُمان"]
      };

  const esc = value =>
    String(value).replace(/[&<>"']/g, character => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    })[character]);
  const kicker = text =>
    `<p class="section-kicker"><span class="eyebrow-dot" aria-hidden="true"></span>${esc(text)}</p>`;
  const nav = t.nav.map(([label, slug]) =>
    `<a href="${pathFor(slug)}" ${page === slug ? 'aria-current="page"' : ""}>${esc(label)}</a>`
  ).join("");
  const header = `
    <header class="site-header">
      <div class="container wrap header-inner">
        <a class="brand" href="${pathFor("home")}" aria-label="${esc(t.brand)}">
          <img src="${basePath}/assets/masarak-logo-original.webp" alt="${esc(t.brand)}" />
        </a>
        <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-nav">
          <span class="sr-only">${isEnglish ? "Open navigation" : "فتح قائمة التنقل"}</span>
          <span></span><span></span><span></span>
        </button>
        <nav class="primary-nav site-nav" id="primary-nav" aria-label="${isEnglish ? "Main navigation" : "التنقل الرئيسي"}">${nav}</nav>
        <div class="header-actions">
          <a class="language-link language-switch" href="${pathFor(page, !isEnglish)}" lang="${isEnglish ? "ar" : "en"}">${t.language}</a>
          <a class="button button-primary button-small" href="${whatsappUrl("967784888511")}" target="_blank" rel="noopener noreferrer">${isEnglish ? "WhatsApp us" : "ابدأ محادثة واتساب"}<span class="button-arrow" aria-hidden="true">↗</span></a>
        </div>
      </div>
    </header>`;

  const countries = `<section class="region-band market-strip"><div class="container wrap region-inner market-inner"><div>${kicker(isEnglish ? "Remote service" : "نخدم عن بُعد")}<h2>${esc(t.countriesTitle)}</h2></div><ul class="country-list market-list">${t.countries.map(country => `<li>${esc(country)}</li>`).join("")}</ul></div></section>`;
  const cta = (title, text, button = t.ctaButton) => `
    <section class="cta-band cta-section"><div class="container wrap cta-inner"><div>${kicker(isEnglish ? "Get in touch" : "تواصل معنا")}<h2>${esc(title)}</h2><p>${esc(text)}</p></div><a class="button button-primary" href="${whatsappUrl("967784888511")}" target="_blank" rel="noopener noreferrer">${esc(button)}<span class="button-arrow" aria-hidden="true">↗</span></a></div></section>`;
  const pageHeading = (eyebrow, title, intro, showCharacter = true) => `
    <section class="page-hero"><div class="container wrap page-hero-inner${showCharacter ? "" : " page-hero-inner-home"}"><div class="page-hero-copy">${kicker(eyebrow)}<h1>${esc(title)}</h1><p>${esc(intro)}</p></div>${showCharacter ? `<div class="page-hero-character"><img src="${basePath}/assets/route-partner.svg?v=3" alt="${isEnglish ? "Masarak Advertising route partner" : "شريك مسارك الإعلاني"}" /></div>` : ""}</div><span class="page-hero-shape" aria-hidden="true"></span></section>`;

  function renderHome() {
    const data = t.home;
    return `
      ${isEnglish
        ? pageHeading(data.eyebrow, data.title, data.intro, false)
        : `<section class="home-banner"><img src="${basePath}/assets/masarak-banner.png" alt="مسارك الإعلاني: تسويق بخطة ونتائج تقاس، ونحن معك في كل خطوة." /></section>`}
      <div class="container wrap home-actions"><a class="button button-primary" href="${whatsappUrl("967784888511")}" target="_blank" rel="noopener noreferrer">${esc(data.primary)}<span class="button-arrow" aria-hidden="true">↗</span></a><a class="home-services-link" href="${pathFor("services")}">${esc(data.secondary)}<span aria-hidden="true"> →</span></a></div>
      ${countries}
      <section class="section container wrap"><div class="section-heading section-heading-row"><div>${kicker(data.sectorsLabel)}<h2>${esc(data.sectorsTitle)}</h2></div><p>${esc(data.sectorsIntro)}</p></div>
        <div class="card-grid sector-grid">${data.sectors.map(([title, text], index) => `<article class="sector-card"><span class="card-index">${String(index + 1).padStart(2, "0")}</span><h3>${esc(title)}</h3><p>${esc(text)}</p></article>`).join("")}</div>
      </section>
      <section class="section challenge-section"><div class="container wrap challenge-layout"><div class="challenge-copy">${kicker(data.challengeLabel)}<h2>${esc(data.challengeTitle)}</h2><p>${esc(data.challengeText)}</p><ul class="challenge-list">${data.challengeItems.map(item => `<li>${esc(item)}</li>`).join("")}</ul></div><aside class="response-card"><span class="response-symbol" aria-hidden="true">↗</span><h3>${esc(data.asideTitle)}</h3><p>${esc(data.asideText)}</p><a class="text-link" href="${pathFor("contact")}">${isEnglish ? "Contact us" : "تواصل معنا"}<span aria-hidden="true"> →</span></a></aside></div></section>
      <section class="section container wrap"><div class="section-heading section-heading-row"><div>${kicker(data.stepsLabel)}<h2>${esc(data.stepsTitle)}</h2></div><p>${esc(data.stepsIntro)}</p></div><div class="pillar-grid">${data.steps.map(([number, label], index) => `<article class="pillar-card"><span class="pillar-index">${String(index + 1).padStart(2, "0")}</span><h3>${esc(label)}</h3></article>`).join("")}</div></section>
      ${cta(data.ctaTitle, data.ctaText)}`;
  }

  function renderServices() {
    const data = t.services;
    return `${pageHeading(data.eyebrow, data.title, data.intro)}
      <section class="section container wrap"><div class="card-grid service-grid">${data.items.map(([title, text], index) => `<article class="service-card"><div class="service-card-top"><span class="service-number">${String(index + 1).padStart(2, "0")}</span><span class="service-glyph" aria-hidden="true"><span></span><span></span><span></span></span></div><h2>${esc(title)}</h2><p>${esc(text)}</p></article>`).join("")}</div></section>
      ${cta(data.ctaTitle, data.ctaText, data.ctaButton)}${countries}`;
  }

  function renderAbout() {
    const data = t.about;
    return `${pageHeading(data.eyebrow, data.title, data.intro)}
      <section class="section container wrap"><div class="about-layout"><div class="about-statement">${kicker(data.stepsLabel)}<h2>${esc(data.stepsTitle)}</h2><p>${esc(data.stepsIntro)}</p></div><div class="method-list">${data.steps.map(([number, title, description]) => `<article class="method-step"><span class="method-number">${esc(number)}</span><div><h3>${esc(title)}</h3><p>${esc(description)}</p></div></article>`).join("")}</div></div></section>
      <section class="reach-section"><div class="container wrap reach-inner"><div class="reach-icon" aria-hidden="true"><span></span><span></span><span></span></div><div>${kicker(isEnglish ? "Where we work" : "نطاق الخدمة")}<h2>${esc(data.regionTitle)}</h2><p>${esc(data.regionText)}</p></div></div></section>
      ${cta(data.ctaTitle, data.ctaText)}${countries}`;
  }

  function renderPortfolio() {
    const data = t.portfolio;
    return `${pageHeading(data.eyebrow, data.title, data.intro)}
      <section class="section container wrap portfolio-section"><div class="portfolio-empty"><span class="portfolio-mark" aria-hidden="true"><span class="portfolio-mark-ring"></span><span class="portfolio-mark-line"></span><span class="portfolio-mark-dot"></span></span>${kicker(isEnglish ? "Portfolio status" : "حالة معرض الأعمال")}<h2>${esc(data.emptyTitle)}</h2><p>${esc(data.emptyText)}</p><a class="button button-primary" href="${pathFor("contact")}">${isEnglish ? "Contact us" : "تواصل معنا"}<span class="button-arrow" aria-hidden="true">↗</span></a></div></section>
      ${cta(data.emptyTitle, data.emptyText)}`;
  }

  function renderContact() {
    const data = t.contact;
    const phones = [
      [data.numberOne, "967784888511", "+967 784 888 511"],
      [data.numberTwo, "967783487708", "+967 783 487 708"]
    ];
    return `${pageHeading(data.eyebrow, data.title, data.intro)}
      <section class="section container wrap"><div class="contact-layout"><div class="contact-intro">${kicker(data.channels)}<h2>${esc(data.channelsTitle)}</h2><p>${esc(data.channelsText)}</p><p class="subtle-note">${esc(data.remote)}</p></div>
        <div class="contact-options">${phones.map(([label, number, display]) => `<article class="contact-card"><div><p class="contact-label">${esc(label)}</p><a class="contact-number" href="tel:+${number}">${display}</a></div><div class="contact-actions"><a class="button button-primary button-small" href="${whatsappUrl(number)}" target="_blank" rel="noopener noreferrer">${esc(data.whatsapp)}<span class="button-arrow" aria-hidden="true">↗</span></a><a class="phone-link" href="tel:+${number}">${esc(data.phone)}</a></div></article>`).join("")}</div></div>
      </section>
      <section class="social-section"><div class="container wrap social-inner"><div>${kicker(data.social)}<h2>${esc(data.socialTitle)}</h2></div><div class="social-list"><a href="https://www.instagram.com/masarkadvertising/" target="_blank" rel="noopener noreferrer"><span class="social-badge" aria-hidden="true">◎</span><span>Instagram<bdi>@masarkadvertising</bdi></span></a><a href="https://www.facebook.com/masarkadvertising/" target="_blank" rel="noopener noreferrer"><span class="social-badge" aria-hidden="true">f</span><span>Facebook<bdi>@masarkadvertising</bdi></span></a></div></div></section>
      ${countries}`;
  }

  const content = ({
    home: renderHome,
    services: renderServices,
    about: renderAbout,
    portfolio: renderPortfolio,
    contact: renderContact
  }[page] || renderHome)();
  const footer = `
    <footer class="site-footer"><div class="container wrap footer-grid">
      <div class="footer-brand"><a class="brand brand-footer" href="${pathFor("home")}"><img src="${basePath}/assets/masarak-logo-original.webp" alt="${esc(t.brand)}" /></a><p>${esc(t.tagline)}</p><p class="footer-reach">${esc(t.footerRemote)}</p></div>
      <div><h2 class="footer-heading">${esc(t.footerLinks)}</h2><ul class="footer-links">${t.nav.map(([label, slug]) => `<li><a href="${pathFor(slug)}">${esc(label)}</a></li>`).join("")}</ul></div>
      <div><h2 class="footer-heading">${esc(t.footerSocial)}</h2><a class="footer-chat" href="${whatsappUrl("967784888511")}" target="_blank" rel="noopener noreferrer">${isEnglish ? "WhatsApp" : "واتساب"} · +967 784 888 511</a><a class="social-link" href="https://www.instagram.com/masarkadvertising/" target="_blank" rel="noopener noreferrer">Instagram · @masarkadvertising</a><a class="social-link" href="https://www.facebook.com/masarkadvertising/" target="_blank" rel="noopener noreferrer">Facebook · @masarkadvertising</a></div>
    </div><div class="container footer-bottom"><span>${esc(t.brand)}</span><span>${esc(isEnglish ? "We work remotely; no local office address is listed." : "نعمل عن بُعد ولا نعرض عنوان مكتب محلي.")}</span></div></footer>`;
  document.documentElement.lang = isEnglish ? "en" : "ar";
  document.documentElement.dir = isEnglish ? "ltr" : "rtl";
  const pageTitle = page === "home"
    ? (isEnglish ? "A clearer marketing path" : "تسويق مترابط من الخطة إلى الحملة")
    : t.nav.find(([, slug]) => slug === page)?.[0] || t.brand;
  document.title = `${pageTitle} | ${t.brand}`;
  document.querySelector('meta[name="description"]').content =
    page === "home" ? t.home.intro : t[page]?.intro || t.brand;
  document.getElementById("site").innerHTML = `${header}<main id="main">${content}</main>${footer}`;
  const toggle = document.querySelector(".menu-toggle");
  const navElement = document.querySelector(".primary-nav");
  toggle.addEventListener("click", () => {
    const expanded = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", String(!expanded));
    navElement.classList.toggle("is-open", !expanded);
  });
  navElement.addEventListener("click", event => {
    if (event.target instanceof HTMLAnchorElement) {
      toggle.setAttribute("aria-expanded", "false");
      navElement.classList.remove("is-open");
    }
  });
})();
